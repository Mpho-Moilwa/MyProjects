public interface Processable
{
    double calculateTotalCost();
}