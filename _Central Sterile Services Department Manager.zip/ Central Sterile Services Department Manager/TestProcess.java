import java.util.ArrayList;

public class TestProcess 
{
    public static void displaySterilisationProcesses(ArrayList<Processable> list) 
    {
        System.out.println("====== Sterilisation Processes ======");
        System.out.println("Technician\tContact Num\tSessions\tMethod\tItems\tCycles\tPrice(ps)\tTotal Cost");

        for (Processable p : list) {

            if (p instanceof Sterilisation) 
            {

                Sterilisation s = (Sterilisation) p;

                System.out.println(
                        s.getName() + "\t" +
                        s.getContactNumber() + "\t" +
                        s.getNumSessions() + "\t" +
                        s.getProcessType() + "\t" +   
                        s.getNumItems() + "\t" +
                        s.getCycles() + "\t" +
                        String.format("R%.2f", s.getPricePerSession()) + "\t" +
                        String.format("R%.2f", p.calculateTotalCost()) 
                );
            }
        }
    }

    public static void displaySanitisationProcesses(ArrayList<Processable> list) 
    {
        System.out.println("\n====== Sanitisation Processes ======");
        System.out.println("Technician\tContact Num\tSessions\tArea\tCompliance(ps)\tPrice(ps)\tTotal Cost");

        for (Processable p : list) {

            if (p instanceof Sanitisation) 
            {

                Sanitisation s = (Sanitisation) p;

                System.out.println(
                        s.getName() + "\t" +
                        s.getContactNumber() + "\t" +
                        s.getNumSessions() + "\t" +
                        s.getArea() + "\t" +
                        String.format("R%.2f", s.getComplianceFee()) + "\t" +
                        String.format("R%.2f", s.getPricePerSession()) + "\t" +
                        String.format("R%.2f", p.calculateTotalCost()) // 
                );
            }
        }
    }

    public static void main(String[] args) 
    {
        FileHandler fh = new FileHandler("processes.txt");
        ArrayList<Processable> processes = fh.getProcesses();

        displaySterilisationProcesses(processes);
        displaySanitisationProcesses(processes);

        SerializationHandler.serializeProcesses(processes);

        ArrayList<Processable> restored =
                SerializationHandler.deserializeProcesses();

        if (restored != null) 
        {
            System.out.println(restored.size() + " process records restored from processes.ser");
        }

        fh.writeAutoclaveToFile();
    }
}