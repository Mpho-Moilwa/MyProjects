public class Sanitisation extends SterilisationProcess implements Processable
{
    private double area;
    private double complianceFee;
    private double pricePerSession;
    
    public Sanitisation()
    {
        super();
    }
    
    public Sanitisation(char processType, String name, String contactNumber, int numSessions, double area, double complianceFee, double pricePerSession)
    {
        super(processType, name, contactNumber, numSessions);
        this.area = area;
        this.complianceFee  = complianceFee;
        this.pricePerSession = pricePerSession;
    }
    
    public double getArea()
    {
        return area;
    }
    
    public double getComplianceFee()
    {
        return complianceFee;
    }
    
    public double getPricePerSession()
    {
        return pricePerSession;
    }
    
    public double calcPricePerSession()
    {
        return area * 95.0;
    }
    
    public double calcComplianceFee()
    {
        return area * 25.0;
    }
    
    @Override
    public double calculateTotalCost() 
    {
        return pricePerSession * getNumSessions();
    }
    
    @Override
    public String toString() 
    {
        return super.toString() + "\n" +
               area + "\n" +
               String.format("R%.2f", complianceFee) + "\n" +
               String.format("R%.2f", pricePerSession);
    }
}