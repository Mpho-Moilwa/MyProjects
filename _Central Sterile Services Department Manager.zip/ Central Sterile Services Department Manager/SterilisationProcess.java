import java.io.Serializable;

public class SterilisationProcess implements Serializable
{
    private static final long serialVersionUID = 1L;
    
    private char processType;
    private String name;
    private String contactNumber;
    private int numSessions;
    
    public SterilisationProcess()
    {
        
    }
    
    public SterilisationProcess(char processType, String name, String contactNumber, int numSessions) 
    {
        this.processType = processType;
        this.name = name;
        this.contactNumber = contactNumber;
        this.numSessions = numSessions;
    }
    
    public char getProcessType()
    {
        return processType;
    }
    
    public String getName()
    {
        return name;
    }
    
    public String getContactNumber()
    {
        return contactNumber;
    }
    
    public int getNumSessions()
    {
        return numSessions;
    }
    
    @Override
    public String toString()
    {
        return name + "\n" + 
               contactNumber + "\n" + 
               numSessions;
    }
}