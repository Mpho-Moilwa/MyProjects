public class Sterilisation extends SterilisationProcess implements Processable
{
    private char methodType;
    private int numItems;
    private int cycles;
    private double pricePerSession;
    
    
    public Sterilisation()
    {
        super();
    }
    
    public Sterilisation(char processType, String name, String contactNumber, int numSessions, char methodType, int numItems, int cycles, double pricePerSession)
    {
        super(processType, name, contactNumber, numSessions);
        this.methodType = methodType;
        this.numItems = numItems;
        this.cycles = cycles;
        this.pricePerSession = pricePerSession;
    }
    
    public char getProcessType()
    {
        return methodType;
    }
    
    public int getNumItems()
    {
        return numItems;
    }
    
    public int getCycles()
    {
        return cycles;
    }
    
    public double getPricePerSession()
    {
        return pricePerSession;
    }
    
    public double calcPricePerSession()
    {
        switch (methodType) 
        {
            case 'A':
                return 300 + (80 * numItems);
                
            case 'D':
                return 500 + (120 * numItems);
                
            case 'C': 
                return 200 + (60 * numItems);
            default: return 0;
        }
    }
    
    @Override
    public double calculateTotalCost()
    {
        return pricePerSession * getNumSessions();
    }
    
    @Override
    public String toString()
    {
        return super.toString() + "\n" + 
               methodType + "\n" + 
               numItems + "\n" + 
               cycles + "\n" + 
               String.format("R%2f", pricePerSession);
    }
}

