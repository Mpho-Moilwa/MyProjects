import java.io.*;
import java.util.ArrayList;

public class SerializationHandler 
{
    public static void serializeProcesses(ArrayList<Processable> processes) 
    {

        try (ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream("processes.ser")))
        {
            out.writeObject(processes);
            System.out.println("Processes serialised successfully.");

        } catch (IOException e) 
        {
            System.out.println("Serialisation error: " + e.getMessage());
        }
    }

    public static ArrayList<Processable> deserializeProcesses() 
    {
        try (ObjectInputStream in = new ObjectInputStream(new FileInputStream("processes.ser"))) {

            ArrayList<Processable> list =
                    (ArrayList<Processable>) in.readObject();

            System.out.println("Processes deserialised successfully.");
            return list;

        } catch (IOException | ClassNotFoundException e) {

            System.out.println("Deserialisation error: " + e.getMessage());
            return null;
        }
    }
}