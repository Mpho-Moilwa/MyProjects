import java.io.*;
import java.util.ArrayList;

public class FileHandler {

    private ArrayList<Processable> processes = new ArrayList<>();

    public FileHandler(String filename) 
    {
        createSampleFile(filename); 
        readFile(filename);
    }

    private void createSampleFile(String filename)
    {
        try (PrintWriter pw = new PrintWriter(new FileWriter(filename)))
        {
            pw.println("S#Dr. Nkosi#0112345678#3#A#15#2");
            pw.println("S#Sister Dlamini#0823456789#5#D#10#3");
            pw.println("N#T. Mokoena#0734567890#2#150");
            pw.println("S#Dr. van der Berg#0845678901#4#C#8#1");
            pw.println("N#Priya Pillay#0756789012#6#200");
            pw.println("N#James Sithole#0867890123#3#175");
            pw.println("S#Dr. Osei#0798901234#7#A#20#4");

            System.out.println("processes.txt file created successfully.");

        } catch (IOException e)
        {
            System.out.println("Error creating file: " + e.getMessage());
        }
    }

    private void readFile(String filename) 
    {
        try (BufferedReader br = new BufferedReader(new FileReader(filename))) 
        {
            String line;

            while ((line = br.readLine()) != null) 
            {
                String[] parts = line.split("#");

                char type = parts[0].charAt(0);
                String name = parts[1];
                String contact = parts[2];
                int sessions = Integer.parseInt(parts[3]);

                if (type == 'S') 
                {
                    char method = parts[4].charAt(0);
                    int items = Integer.parseInt(parts[5]);
                    int cycles = Integer.parseInt(parts[6]);

                    double price = 0;

                    switch (method) {
                        case 'A':
                            price = 300 + (80 * items);
                            break;
                        case 'D':
                            price = 500 + (120 * items);
                            break;
                        case 'C':
                            price = 200 + (60 * items);
                            break;
                    }

                    processes.add(new Sterilisation(
                            type, name, contact, sessions,
                            method, items, cycles, price
                    ));

                } else if (type == 'N') 
                {
                    double area = Double.parseDouble(parts[4]);

                    double price = area * 95.0;
                    double compliance = area * 25.0;

                    processes.add(new Sanitisation(
                            type, name, contact, sessions,
                            area, compliance, price
                    ));
                }
            }

        } catch (IOException e) 
        {
            System.out.println("Error reading file: " + e.getMessage());
        }
    }

    public ArrayList<Processable> getProcesses() {
        return processes;
    }

    public void writeAutoclaveToFile() 
    {
        try (PrintWriter pw = new PrintWriter(new FileWriter("autoclave_records.txt"))) {

            for (Processable p : processes) {

                if (p instanceof Sterilisation) {

                    Sterilisation s = (Sterilisation) p;

                    if (s.getProcessType() == 'A') {  
                        pw.println(s.getName());
                        pw.println(s.getContactNumber());
                        pw.println(String.format("R%.2f", s.getPricePerSession()));
                    }
                }
            }

            System.out.println("Autoclave records written to autoclave_records.txt");

        } catch (IOException e) 
        {
            System.out.println("Error writing file: " + e.getMessage());
        }
    }
}