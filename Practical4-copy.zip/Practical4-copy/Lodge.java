public class Lodge extends Accommodation implements Bookable {
    private double size;
    private double insurancePerNight;
    private double pricePerNight;
    private static final double PRICE_PER_SQ_METER = 350.00;

    public Lodge() {
        super();
        this.size = 0;
        this.insurancePerNight = 0.0;
        this.pricePerNight = 0.0;
    }

    public Lodge(String guestName, String contactNumber, int duration, double size) {
        super("L", guestName, contactNumber, duration);
        this.size = size;
        this.insurancePerNight = calcNightlyInsurance();
        this.pricePerNight = calcPricePerNight();
    }

    public double getSize() {
        return size;
    }

    public double getInsurancePerNight() {
        return insurancePerNight;
    }

    public double getPricePerNight() {
        return pricePerNight;
    }

    public double calcNightlyInsurance() {
        return size * PRICE_PER_SQ_METER * 0.10;
    }

    public double calcPricePerNight() {
        return (size * PRICE_PER_SQ_METER) + insurancePerNight;
    }

    @Override
    public double calculatePrice() {
        return calcPricePerNight() * getDuration();
    }

    @Override
    public String toString() {
        return super.toString() + " " + (int)size + " R" + String.format("%.2f", insurancePerNight * getDuration()) + 
               " R" + String.format("%.2f", calculatePrice());
    }
}