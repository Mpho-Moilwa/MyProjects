public class Hotel extends Accommodation implements Bookable {
    private char roomType;
    private int numBeds;
    private int numBathrooms;
    private int numParkingSpaces;
    private double pricePerNight;

    public Hotel() {
        super();
        this.roomType = ' ';
        this.numBeds = 0;
        this.numBathrooms = 0;
        this.numParkingSpaces = 0;
        this.pricePerNight = 0.0;
    }

    public Hotel(String guestName, String contactNumber, int duration, 
                 char roomType, int numBeds, int numBathrooms, int numParkingSpaces) {
        super("H", guestName, contactNumber, duration);
        this.roomType = roomType;
        this.numBeds = numBeds;
        this.numBathrooms = numBathrooms;
        this.numParkingSpaces = numParkingSpaces;
        this.pricePerNight = calcPricePerNight();
    }

    public char getRoomType() {
        return roomType;
    }

    public int getNumBeds() {
        return numBeds;
    }

    public int getNumBathrooms() {
        return numBathrooms;
    }

    public int getNumParkingSpaces() {
        return numParkingSpaces;
    }

    public double getPricePerNight() {
        return pricePerNight;
    }

    public double calcPricePerNight() {
        double basePrice = 0;
        double bedPrice = 0;

        if (roomType == 'S' || roomType == 's') {
            basePrice = 500;
            bedPrice = 100;
        } else if (roomType == 'D' || roomType == 'd') {
            basePrice = 800;
            bedPrice = 150;
        } else if (roomType == 'T' || roomType == 't') {
            basePrice = 1200;
            bedPrice = 200;
        }

        return basePrice + (bedPrice * numBeds);
    }

    @Override
    public double calculatePrice() {
        return calcPricePerNight() * getDuration();
    }

    @Override
    public String toString() {
        return super.toString() + " " + roomType + " " + numBeds + " " + numBathrooms + 
               " R" + String.format("%.0f", calculatePrice());
    }
}