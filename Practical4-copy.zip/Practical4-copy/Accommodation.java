public  class Accommodation {
    private String type;
    private String guestName;
    private String contactNumber;
    private int duration;

    public Accommodation() {
        this.type = "";
        this.guestName = "";
        this.contactNumber = "";
        this.duration = 0;
    }

    public Accommodation(String type, String guestName, String contactNumber, int duration) {
        this.type = type;
        this.guestName = guestName;
        this.contactNumber = contactNumber;
        this.duration = duration;
    }

    public String getType() {
        return type;
    }

    public String getGuestName() {
        return guestName;
    }

    public String getContactNumber() {
        return contactNumber;
    }

    public int getDuration() {
        return duration;
    }

    @Override
    public String toString() {
        return guestName + " " + contactNumber + " " + duration;
    }
}