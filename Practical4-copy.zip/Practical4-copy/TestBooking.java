import java.util.ArrayList;
import java.io.PrintWriter;
import java.io.FileWriter;

public class TestBooking {
    
    public static void createBookingsFile() {
        try {
            PrintWriter pw = new PrintWriter(new FileWriter("bookings.txt"));
            pw.println("H#Joe Bloom#0879678223#24#T#4#3");
            pw.println("H#Sam Xaba#0849558202#12#S#2#1");
            pw.println("L#Sue Smith#0723456872#12#280");
            pw.println("H#Lee West#0826458288#12#T#3#2");
            pw.println("L#John Pule#0723456872#24#320");
            pw.println("L#Abe Thiem#0843412573#6#330");
            pw.println("H#Craig Moore#0721236285#18#D#3#2");
            pw.close();
            System.out.println("bookings.txt created successfully");
        } catch (Exception e) {
            System.out.println("Error creating file: " + e.getMessage());
        }
    }
    
    public static void displayHotels(ArrayList<Bookable> bookings) {
        System.out.println("\n========== Hotel Accommodations ==========");
        System.out.printf("%-15s %-12s %-7s %-5s %-5s %-6s %-12s%n", 
                         "Name", "Cell num", "Nights", "Type", "Beds", "Baths", "Price (pn)");
        System.out.println("---------------------------------------------------------------");
        
        for (Bookable b : bookings) {
            if (b instanceof Hotel) {
                Hotel h = (Hotel) b;
                System.out.printf("%-15s %-12s %-7d %-5c %-5d %-6d R%-11.2f%n",
                    h.getGuestName(),
                    h.getContactNumber(),
                    h.getDuration(),
                    h.getRoomType(),
                    h.getNumBeds(),
                    h.getNumBathrooms(),
                    h.calculatePrice());
            }
        }
    }

    public static void displayLodges(ArrayList<Bookable> bookings) {
        System.out.println("\n========== Lodge Accommodations ==========");
        System.out.printf("%-15s %-12s %-7s %-6s %-14s %-12s%n", 
                         "Name", "Cell num", "Nights", "Size", "Insurance(pn)", "Price (pn)");
        System.out.println("-------------------------------------------------------------------");
        
        for (Bookable b : bookings) {
            if (b instanceof Lodge) {
                Lodge l = (Lodge) b;
                System.out.printf("%-15s %-12s %-7d %-6.0f R%-13.2f R%-11.2f%n",
                    l.getGuestName(),
                    l.getContactNumber(),
                    l.getDuration(),
                    l.getSize(),
                    l.getInsurancePerNight() * l.getDuration(),
                    l.calculatePrice());
            }
        }
    }

    public static void main(String[] args) {
        createBookingsFile();
        
        FileHandler fileHandler = new FileHandler();
        fileHandler.readFromFile("bookings.txt");
        
        ArrayList<Bookable> bookings = fileHandler.getBookings();
        
        displayHotels(bookings);
        
        displayLodges(bookings);
        
        fileHandler.writeDoublesToFile("double_rooms.txt", bookings);
        
        System.out.println("\nDouble room information written to double_rooms.txt");
    }
}