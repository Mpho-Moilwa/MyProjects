import java.io.*;
import java.util.ArrayList;

public class FileHandler {
    private ArrayList<Bookable> bookings;

    public FileHandler() {
        this.bookings = new ArrayList<>();
    }

    public void readFromFile(String filename) {
        try (BufferedReader br = new BufferedReader(new FileReader(filename))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] parts = line.split("#");
                
                if (parts.length > 0) {
                    String type = parts[0].trim();
                    String guestName = parts[1].trim();
                    String contactNumber = parts[2].trim();
                    int duration = Integer.parseInt(parts[3].trim());

                    if (type.equals("H") && parts.length >= 7) {
                        char roomType = parts[4].trim().charAt(0);
                        int numBeds = Integer.parseInt(parts[5].trim());
                        int numBathrooms = Integer.parseInt(parts[6].trim());
                        int numParking = (parts.length > 7) ? Integer.parseInt(parts[7].trim()) : 0;
                        
                        Hotel hotel = new Hotel(guestName, contactNumber, duration, 
                                               roomType, numBeds, numBathrooms, numParking);
                        bookings.add(hotel);
                    } 
                    else if (type.equals("L") && parts.length >= 5) {
                        double size = Double.parseDouble(parts[4].trim());
                        
                        Lodge lodge = new Lodge(guestName, contactNumber, duration, size);
                        bookings.add(lodge);
                    }
                }
            }
        } catch (Exception e) {
            System.out.println("Error reading file: " + e.getMessage());
        }
    }

    public ArrayList<Bookable> getBookings() {
        return bookings;
    }

    public void writeDoublesToFile(String filename, ArrayList<Bookable> bookings) {
        try (PrintWriter writer = new PrintWriter(new FileWriter(filename))) {
            for (Bookable b : bookings) {
                if (b instanceof Hotel) {
                    Hotel h = (Hotel) b;
                    if (h.getRoomType() == 'D' || h.getRoomType() == 'd') {
                        writer.println(h.getGuestName() + " " + h.getContactNumber() + 
                                     " R" + String.format("%.2f", h.calculatePrice()));
                    }
                }
            }
        } catch (Exception e) {
            System.out.println("Error writing to file: " + e.getMessage());
        }
    }
}