public interface Bookable {
    double calculatePrice();
}