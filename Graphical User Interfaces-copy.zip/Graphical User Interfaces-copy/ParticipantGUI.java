

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.geometry.Insets;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;
import javafx.scene.control.Alert;
import javafx.scene.control.TextField;
import javafx.scene.control.TextArea;

public class ParticipantGUI extends Application
{
    private Label lblParticipantId;
    private Label lblName;
    private Label lblAge;
    private Label lblParticipant;

    private TextField txtParticipantId;
    private TextField txtName;
    private TextField txtAge;

    private TextArea txaOutput;

    private Button btnAdd;
    private Button btnRemove;
    private Button btnClear;
    private Button btnExit;

    private GridPane pane;

    private ParticipantManager manager;

    @Override
    public void start(Stage primaryStage)
    {
        manager = new ParticipantManager();

        lblParticipantId = new Label("Participant ID:");
        lblName = new Label("Name:");
        lblAge = new Label("Age:");
        lblParticipant = new Label("Participants:");

        txtParticipantId = new TextField();
        txtName = new TextField();
        txtAge = new TextField();

        txaOutput = new TextArea();
        txaOutput.setEditable(false);

        btnAdd = new Button("Add");
        btnRemove = new Button("Remove");
        btnClear = new Button("Clear");
        btnExit = new Button("Exit");

        btnAdd.setOnAction(this::addParticipantClick);
        btnRemove.setOnAction(this::removeParticipantClick);
        btnClear.setOnAction(this::clearFieldsClick);
        btnExit.setOnAction(this::exitClick);

        pane = new GridPane();
        pane.setPadding(new Insets(10));
        pane.setHgap(10);
        pane.setVgap(10);

        pane.add(lblParticipantId, 0, 0);
        pane.add(txtParticipantId, 1, 0);

        pane.add(lblName, 0, 1);
        pane.add(txtName, 1, 1);

        pane.add(lblAge, 0, 2);
        pane.add(txtAge, 1, 2);

        pane.add(btnAdd, 0, 3);
        pane.add(btnRemove, 1, 3);

        pane.add(btnClear, 0, 4);
        pane.add(btnExit, 1, 4);

        pane.add(lblParticipant, 0, 5);
        pane.add(txaOutput, 0, 6, 2, 1);

        Scene scene = new Scene(pane, 400, 400);

        primaryStage.setTitle("Participation Registration System");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    public void addParticipantClick(javafx.event.ActionEvent event)
    {
        try
        {
            String idText = txtParticipantId.getText().trim();
            String name = txtName.getText().trim();
            String ageText = txtAge.getText().trim();

            if (idText.isEmpty())
            {
                showAlert("Participant ID may not be empty.");
                return;
            }

            if (name.isEmpty())
            {
                showAlert("Name may not be empty.");
                return;
            }

            int participantId = Integer.parseInt(idText);
            int age = Integer.parseInt(ageText);

            if (participantId <= 0)
            {
                showAlert("Participant ID must be greater than 0.");
                return;
            }

            if (age <= 0)
            {
                showAlert("Age must be greater than 0.");
                return;
            }

            Participant participant = new Participant(participantId, name, age);

            if (!manager.addParticipant(participant))
            {
                showAlert("Participant ID already exists.");
                return;
            }

            txaOutput.setText(manager.getAllParticipants());

            clearFields();
        }
        catch (NumberFormatException e)
        {
            showAlert("Participant ID and Age must be valid integers.");
        }
    }

    public void removeParticipantClick(javafx.event.ActionEvent event)
    {
        try
        {
            String idText = txtParticipantId.getText().trim();

            if (idText.isEmpty())
            {
                showAlert("Enter a Participant ID.");
                return;
            }

            int participantId = Integer.parseInt(idText);

            if (!manager.removeParticipant(participantId))
            {
                showAlert("Participant not found.");
            }

            txaOutput.setText(manager.getAllParticipants());

            clearFields();
        }
        catch (NumberFormatException e)
        {
            showAlert("Participant ID must be a valid integer.");
        }
    }

    public void clearFieldsClick(javafx.event.ActionEvent event)
    {
        clearFields();
    }

    public void exitClick(javafx.event.ActionEvent event)
    {
        System.exit(0);
    }

    private void clearFields()
    {
        txtParticipantId.clear();
        txtName.clear();
        txtAge.clear();

        txtParticipantId.requestFocus();
    }

    private void showAlert(String message)
    {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Input Error");
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    public static void main(String[] args)
    {
        launch(args);
    }
}