
/**
 * Write a description of class Participant here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Participant
{
    private int participantId;
    private String name;
    private int age;

    public Participant(int participantId, String name, int age)
    {
        this.participantId = participantId;
        this.name = name;
        this.age = age;
    }

    public int getParticipantId()
    {
        return participantId;
    }

    public String getName()
    {
        return name;
    }

    public int getAge()
    {
        return age;
    }

    @Override
    public String toString()
    {
        return participantId + " - " + name + " - " + age;
    }
}