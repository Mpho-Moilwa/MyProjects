import java.util.ArrayList;

public class ParticipantManager
{
    private ArrayList<Participant> participants;
    
    public ParticipantManager()
    {
        participants = new ArrayList<>();
    }
    
    public boolean addParticipant(Participant participant)
    {
        if (participationExists (participant.getParticipantId()))
        {
            return false;
        }
        
        participants.add(participant);
        return true;
    }
    
    public boolean removeParticipant(int participantId)
    {
        for (Participant participant : participants)
        {
            if (participant.getParticipantId() == participantId)
            {
                participants.remove(participant);
                return true;
            }
        }
        
        return false;
    }
    
    public boolean participationExists(int participantId)
    {
        for (Participant participant : participants)
        {
            if (participant.getParticipantId() == participantId)
            {
                return true;
            }
        }

        return false;
    }
    
     public String getAllParticipants()
    {
        if (participants.isEmpty())
        {
            return "No participants registered.";
        }

        String output = "";

        for (Participant participant : participants)
        {
            output += participant.toString() + "\n";
        }

        return output;
    }
}
