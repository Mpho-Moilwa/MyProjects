public class LineFollower extends Robot
{
    private int distance;
    private int time;

    public LineFollower(String reg,
                        String name,
                        int age,
                        int distance,
                        int time)
    {
        super(reg,name,age);

        validateRegistration(reg);

        this.distance = distance;
        this.time = time;
    }

    private void validateRegistration(String reg)
    {
        if(reg.length() != 6)
        {
            throw new InvalidInputException(
                "Incorrect registration "
                + reg
                + ": Length must be 6.");
        }

        if(reg.charAt(0) != 'L')
        {
            throw new InvalidInputException(
                "Incorrect registration "
                + reg
                + ": Must start with L.");
        }

        for(int i=1;i<6;i++)
        {
            if(!Character.isDigit(reg.charAt(i)))
            {
                throw new InvalidInputException(
                    "Incorrect registration "
                    + reg
                    + ": Positions 2 to 6 may only be digits.");
            }
        }
    }

    @Override
    public int calculateScore()
    {
        return (int)Math.round(
                (double)distance/time);
    }

    @Override
    public String toString()
    {
        return registrationID + "\t"
                + name + "\t"
                + ageGroup + "\t"
                + distance + "\t"
                + time + "\t"
                + calculateScore();
    }
}