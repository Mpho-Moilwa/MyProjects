import java.io.*;
import java.util.*;

public class Scoring
{
    private Robot[] robots;
    private int count;

    public Scoring()
    {
        robots = new Robot[25];
        count = 0;
    }

    public void readFromFile(String fileName)
    {
        try
        {
            Scanner input =
                    new Scanner(new File(fileName));

            while(input.hasNextLine())
            {
                String line = input.nextLine();

                String[] data =
                        line.split("@");

                String reg = data[0];
                String name = data[1];
                int age =
                        Integer.parseInt(data[2]);

                if(reg.startsWith("L"))
                {
                    int distance =
                            Integer.parseInt(data[3]);

                    int time =
                            Integer.parseInt(data[4]);

                    robots[count++] =
                            new LineFollower(
                                    reg,
                                    name,
                                    age,
                                    distance,
                                    time);
                }
                else
                {
                    int collected =
                            Integer.parseInt(data[3]);

                    int penalties =
                            Integer.parseInt(data[4]);

                    robots[count++] =
                            new RoboSoccer(
                                    reg,
                                    name,
                                    age,
                                    collected,
                                    penalties);
                }
            }

            input.close();
        }
        catch(Exception e)
        {
            System.out.println(e.getMessage());
        }
    }

    public void displayRobots()
    {
        for(int i=0;i<count;i++)
        {
            System.out.println(robots[i]);
        }
    }

    public void displayTotals()
    {
        int balls = 0;
        int penalties = 0;

        for(int i=0;i<count;i++)
        {
            if(robots[i] instanceof RoboSoccer)
            {
                RoboSoccer rs =
                        (RoboSoccer)robots[i];

                balls += rs.getCollected();
                penalties += rs.getPenalties();
            }
        }

        System.out.println(
                "\nTotal balls collected: "
                        + balls);

        System.out.println(
                "Total penalties: "
                        + penalties);
    }

    public void sortScores()
    {
        Arrays.sort(robots,0,count);
    }

    public void serializeToFile()
    {
        try
        {
            ObjectOutputStream out =
                    new ObjectOutputStream(
                            new FileOutputStream(
                                    "scores.ser"));

            for(int i=0;i<count;i++)
            {
                out.writeObject(robots[i]);
            }

            out.close();
        }
        catch(Exception e)
        {
            System.out.println(e.getMessage());
        }
    }

    public void deserializeFromFile()
    {
        try
        {
            ObjectInputStream in =
                    new ObjectInputStream(
                            new FileInputStream(
                                    "scores.ser"));

            while(true)
            {
                Robot r =
                        (Robot)in.readObject();

                System.out.println(
                        r.getRegistrationID()
                                + " "
                                + r.getName());
            }
        }
        catch(EOFException e)
        {
            System.out.println(
                    "End of file reached");
        }
        catch(Exception e)
        {
            System.out.println(
                    e.getMessage());
        }
    }
}