import java.io.Serializable;

public abstract class Robot implements Scorable,
        Serializable, Comparable<Robot>
{
    protected String registrationID;
    protected String name;
    protected int ageGroup;

    public Robot(String registrationID,
                 String name,
                 int ageGroup)
    {
        this.registrationID = registrationID;
        this.name = name;
        this.ageGroup = ageGroup;
    }

    public String getRegistrationID()
    {
        return registrationID;
    }

    public String getName()
    {
        return name;
    }

    public int getAgeGroup()
    {
        return ageGroup;
    }

    public void setAgeGroup(int ageGroup)
    {
        if(ageGroup < 1 || ageGroup > 3)
        {
            throw new InvalidInputException(
                "Invalid age group " + ageGroup +
                ": Must be between 1 and 3.");
        }

        this.ageGroup = ageGroup;
    }

    @Override
    public int compareTo(Robot other)
    {
        if(this.ageGroup != other.ageGroup)
        {
            return this.ageGroup - other.ageGroup;
        }

        return this.calculateScore()
                - other.calculateScore();
    }

    @Override
    public String toString()
    {
        return registrationID + "\t"
                + name + "\t"
                + ageGroup + "\t"
                + calculateScore();
    }
}