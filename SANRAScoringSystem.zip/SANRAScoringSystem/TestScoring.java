public class TestScoring
{
    public static void main(String[] args)
    {
        Scoring s = new Scoring();

        System.out.println(
                "LIST OF ROBOTS");

        s.readFromFile(
                "robotscores.txt");

        s.displayRobots();

        s.displayTotals();

        System.out.println(
                "\nAFTER SORTING");

        s.sortScores();

        s.displayRobots();

        System.out.println(
                "\nSERIALIZING");

        s.serializeToFile();

        System.out.println(
                "\nDESERIALIZING");

        s.deserializeFromFile();
    }
}