public class RoboSoccer extends Robot
{
    private int collected;
    private int penalties;

    public RoboSoccer(String reg,
                      String name,
                      int age,
                      int collected,
                      int penalties)
    {
        super(reg,name,age);

        validateRegistration(reg);

        this.collected = collected;
        this.penalties = penalties;
    }

    private void validateRegistration(String reg)
    {
        if(reg.length() != 6)
        {
            throw new InvalidInputException(
                "Incorrect registration "
                + reg
                + ": Length must be 6.");
        }

        if(reg.charAt(0) != 'R')
        {
            throw new InvalidInputException(
                "Incorrect registration "
                + reg
                + ": Must start with R.");
        }

        for(int i=1;i<6;i++)
        {
            if(!Character.isDigit(reg.charAt(i)))
            {
                throw new InvalidInputException(
                    "Incorrect registration "
                    + reg
                    + ": Positions 2 to 6 may only be digits.");
            }
        }
    }

    public int getCollected()
    {
        return collected;
    }

    public int getPenalties()
    {
        return penalties;
    }

    @Override
    public int calculateScore()
    {
        return collected - penalties;
    }

    @Override
    public String toString()
    {
        return registrationID + "\t"
                + name + "\t"
                + ageGroup + "\t"
                + collected + "\t"
                + penalties + "\t"
                + calculateScore();
    }
}